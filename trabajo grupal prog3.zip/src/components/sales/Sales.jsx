
function Sales() {

    return (    
        <>
        </>
    )
}

export default Sales
